#voucher gojek claim voucher terbaru

voucher go food dan Go ride

syntax code :

pkg update && pkg upgrade

pkg install php

pkg install curl

pkg install git

selanjutnya syntax auto claim voucher gojek :

git clone https://github.com/wildanfauzi1998/procher/

selanjutnya masuk ke folder procher dengan syntax :

cd procher

lalu jalankan php dengan syntax :

php gofood25k.php

Selanjutnya masukkan nomor yang belum pernag di daftar/regis aplikasi gojek(nomor yang belum pernah regis akun gojek).

Lalu cek nomor untuk dapat kode OPT dari sms dan masukkan kode otp ke termux.

setelah sukses dan berhasil daftar/regis akun gojek dengan nomor tadi, selesai.  


